package tiei.ajp.anagram;

public class LetterInventory {
	
	private static final int SIZE_OF_ALPHABET = 26;
	
	private int[] inventory;
	private int size;

	/*
	 * Constructs an inventory (a count) of the alphabetic
	 * letters in the given string input, ignoring the case of
	 * letters and ignoring any non-alphabetic characters.
	 */
	public LetterInventory(String input) {
		inventory = new int[SIZE_OF_ALPHABET];
		for (int i = 0; i < input.length(); i++ ) {
			char c = Character.toLowerCase(input.charAt(i));
			if ( isValidCharacter(c) ) {
				inventory[indexOf(c)]++;
				size++;
			}
		}
	}
	
	/*
	 * Returns true if this inventory is empty (all counts are 0).
	 */
	public boolean isEmpty() {
		return size == 0;
	}
	
	/*
	 * Returns a String representation of the inventory
	 * with the letters all in lowercase and in sorted
	 * order and surrounded by square brackets.
	 */	
	public String toString() {
		String toString = "[";
		for ( int i = 0; i < inventory.length; i++ ) {
			for ( int j = 0; j < inventory[i]; j++ ) {
				toString += letterOf(i);
			}
		}
		toString += ']';
		return toString;
	}
	
	/*
	 * Constructs and returns a new LetterInventory object that
	 * represents the result of subtracting the other inventory
	 * from this inventory (i.e., subtracting the counts in the
	 * other inventory from this object’s counts). If any resulting
	 * count would be negative, returns null. 
	 */
	public LetterInventory subtract(LetterInventory other) {
		LetterInventory newLI = new LetterInventory("");
		for ( int i = 0; i < inventory.length; i++ ) {
			newLI.inventory[i] = inventory[i] - other.inventory[i];
			if ( newLI.inventory[i] < 0 ) {
				return null;
			}
		}
		newLI.size = size - other.size;
		return newLI;
	}
	
	/**
	 * Returns true if this inventory is included in 
	 * the other inventory, false otherwise.
	 */
	public boolean includedIn(LetterInventory other) {
		for ( int i = 0; i < inventory.length; i++ ) {
			if ( inventory[i] > other.inventory[i] ) {
				return false;
			}
		}
		return true;
	}
	
	/*
	 * Returns the index matching the letter c.
	 * Precondition: c must be in lowercase
	 */
	private int indexOf(int c) {
		return c - 'a';
	}
	
	/*
	 * Returns the letter at index i.
	 */
	private char letterOf(int i) {
		return (char) ('a' + i);
	}
	
	/*
	 * Checks if letter c is in the range 'a'..'z'.
	 * Precondition: c must be in lowercase
	 */
	private boolean isValidCharacter(char c) {
		return c >= 'a' &&  c <= 'z';
	}
}
