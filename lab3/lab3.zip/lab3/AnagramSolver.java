//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.anagram;

import java.util.*;

/**
 * A class to solve anagrams
 */
public class AnagramSolver {
	
	private Map<String,LetterCounter> dict;
	
	/**
	 * Makes an AnagramSolver based on the dictionary
	 * stored in the non empty Scanner 'dictionary'
	 */
	public AnagramSolver(Scanner dictionary) {
		dict = new HashMap<>();
		while ( dictionary.hasNext() ) {
			String word = dictionary.next().trim().toLowerCase();
			dict.put( word, new LetterCounter(word) );
		}
	}

	/**
	 * Prints on the standard output all possible anagram
	 * phrases based on the dictionary.
	 * Those phrases may contains up to max words if max > 0
	 * If max = 0, there is no limit in the number of words
	 * in the phrases
	 */
	public void print(String text, int max) {
		LetterCounter textInventory = new LetterCounter(text);
		List<String> pruned = prune(textInventory);
		print(pruned,textInventory,"", max == 0 ? -1 : max);
	}
	
	/**
	 * Prints on the standard output all possible strings made
	 * of prefix concatenated to an anagram phrase based on the
	 * 'pruned' list of words.
	 * Those phrases may contains up to left words if left >= 0
	 */	
	private void print(List<String> pruned, LetterCounter textInventory, String prefix, int left) {
		if ( left == 0 || textInventory.isEmpty() ) {
			System.out.println(prefix);
			return;
		}
		for ( String word : pruned ) {
			LetterCounter tmp = textInventory.subtract(dict.get(word));
			if ( tmp != null ) {
				print(prune(pruned,tmp),tmp, prefix + " " + word, left - 1);
			}
		}
	}
	
	/**
	 * Returns the dictionary pruned by the the 'textInventory'
	 */
	private List<String> prune(LetterCounter textInventory) {
		List<String> pruned = new LinkedList<>();
		for( Map.Entry<String, LetterCounter> entry : dict.entrySet() ) {
			if ( entry.getValue().includedIn(textInventory) )
				pruned.add(entry.getKey());
		}
		return pruned;
	}
	
	/**
	 * Returns the list of words 'words' pruned by the the 'textInventory'
	 */
	private List<String> prune(List<String> words, LetterCounter textInventory) {
		List<String> pruned = new LinkedList<>();
		for( String word : words ) {
			if ( dict.get(word).includedIn(textInventory) )
				pruned.add(word);
		}
		return pruned;
	}
}
