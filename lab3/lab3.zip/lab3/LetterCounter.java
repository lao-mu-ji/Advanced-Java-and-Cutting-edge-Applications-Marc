//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.anagram;

public class LetterCounter {
	
	private MultiSet<Character> mset;

	/*
	 * Constructs an LetterCounter (a count) of the alphabetic
	 * letters in the given string input, ignoring the case of
	 * letters and ignoring any non-alphabetic characters.
	 */
	public LetterCounter(String input) {
		mset = new MultiSet<>();
		for (int i = 0; i < input.length(); i++ ) {
			char c = Character.toLowerCase(input.charAt(i));
			if ( isValidCharacter(c) ) {
				mset.add(c);
			}
		}
	}

	/*
	 * Constructs an LetterCounter (a count) of the alphabetic
	 * letters in the empty string input, in other words, an
	 * empty LetterCounter.
	 */
	public LetterCounter() {
		this("");
	}
	
	/*
	 * Returns true if this LetterCounter is empty (all counts are 0).
	 */
	public boolean isEmpty() {
		return mset.isEmpty();
	}

	/*
	 * Constructs and returns a new LetterCounter object that
	 * represents the result of subtracting the other LetterCounter
	 * from this LetterCounter (i.e., subtracting the counts in the
	 * other LetterCounter from this character’s counts). If any 
	 * resulting count would be negative, returns null. 
	 */
	public LetterCounter subtract(LetterCounter other) {
		LetterCounter result = new LetterCounter();
		for ( MultiSet.Pair<Character> pair : mset ) {
			int n = pair.count() - other.mset.countOf(pair.item());
			if ( n < 0 )
				return null;
			result.mset.add(pair.item(),n);
		}
		return result;
	}

	/**
	 * Returns true if this LetterCounter is included in 
	 * the other inventory, false otherwise.
	 */	
	public boolean includedIn(LetterCounter other) {
		for ( MultiSet.Pair<Character> pair : mset ) {
			if ( pair.count() > other.mset.countOf(pair.item()) )
				return false;
		}
		return true;
	}
	
	/*
	 * Returns a String representation of the LetterCounter
	 * with the letters all in lowercase and in sorted
	 * order and surrounded by square brackets.
	 */	
	public String toString() {
		String toString = "[";
		for ( MultiSet.Pair<Character> pair : mset ) {
			for ( int i = 0; i < pair.count(); i++ ) {
				toString += pair.item();
			}
		}
		toString += ']';
		return toString;
	}
	
	/*
	 * Checks if letter c is in the range 'a'..'z'.
	 * Precondition: c must be in lowercase
	 */
	private boolean isValidCharacter(char c) {
		return c >= 'a' &&  c <= 'z';
	}
	
}
