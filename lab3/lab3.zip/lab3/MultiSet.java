//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.anagram;

import java.util.*;

/**
 * A class for MultiSet
 */
public class MultiSet<T> implements Iterable<MultiSet.Pair<T>> {
	
	private Map<T,Integer> map;
	private int size;
	
	/**
	 * Build an empty MultiSet
	 */
	public MultiSet() {
		map  = new HashMap<>();
		size = 0;
	}
	
	/**
	 * Check if the MultiSet is empty
	 */
	public boolean isEmpty() {
		return size == 0;
	}
	
	/**
	 * Check if the MultiSet contains
	 * at least one occurrence of 'item'
	 */
	public boolean contains(T item) {
		return map.containsKey(item);
	}
	
	/**
	 * Return the number of occurrences
	 * of 'item' in the MultiSet
	 */
	public int countOf(T item) {
		return map.getOrDefault(item, 0);
	}
	
	/**
	 * Add 'item' in the MultiSet
	 */
	public void add(T item) {
		add(item,1);
	}
	
	/**
	 * Add 'n' occurrences of 'item'
	 * in the MultiSet
	 */
	public void add(T item, int n) {
		if ( n > 0 ) {
			map.put(item, map.getOrDefault(item,0) + n);
			size += n;
		}
	}
	
	/**
	 * Remove one occurrence of 'item'
	 * in the MultiSet
	 */
	public void remove(T item) {
		remove(item,1);
	}

	/**
	 * Remove 'n' occurrence of 'item'
	 * in the MultiSet
	 */
	public void remove(T item, int n) {
		int m = map.getOrDefault(item,0) - n;
		if ( m >= 0 ) {
			map.put(item, m);
			size -= n;
			if ( m == 0 )
				map.remove(item);
		}
	}

	/**
	 * Return an iterator on the MultiSet
	 */
	public Iterator<Pair<T>> iterator() {
		return new MultiSetIterator();
	}
	
	private class MultiSetIterator implements Iterator<Pair<T>> {
		 Iterator<T> it;
		 
		 public MultiSetIterator() {
			 it = map.keySet().iterator();
		 }
		 
		 public boolean hasNext() {
			 return it.hasNext();
		 }
		 
		 public Pair<T> next() {
			 T item = it.next();
			 return new Pair<>(item, map.get(item));
		 }
	}
	
	/**
	 * A Pair tye used by the iterator
	 */
	public record Pair<T> (T item, Integer count) {};

}






