//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.shape;

public class Square extends Rectangle {
	
	private static NameGenerator nameGenerator = new NameGenerator("S");
	
	public Square(String name, Point topLeft, double width) {
		super(name, topLeft,width,width);
	}

	public Square(Point topLeft, double width) {
		super(nameGenerator.nextName(),topLeft,width,width);
	}
	
	public Square translated(double dx, double dy) {
		return new Square(getTopLeft().translated(dx, dy),getWidth());
	}
	
	public Square mirror(Point p) {
		Point br = new Point(getTopLeft().getX()+getWidth(),getTopLeft().getY()-getHeight());
		return new Square(br.mirror(p),getWidth());
	}
	
	public Square xMirror(double y) {
		Point bl = new Point(getTopLeft().getX(),getTopLeft().getY()-getHeight());
		Point mbl = bl.xMirror(y);
		return new Square(mbl, getWidth());

	}
	
	public Square yMirror(double x) {
		Point br = new Point(getTopLeft().getX()+getWidth(),getTopLeft().getY()-getHeight());
		Point mbr = br.yMirror(x);
		return new Square(new Point(mbr.getX(),getTopLeft().getY()),getWidth());
	}

	public Type type() {
		return Type.SQUARE;
	}
}
