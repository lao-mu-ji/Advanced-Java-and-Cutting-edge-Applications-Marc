//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.shape;

public class Rectangle extends Shape {
	
	private Point topLeft;
	private double width;
	private double height;
	
	private static NameGenerator nameGenerator = new NameGenerator("R");
	
	public Rectangle(String name, Point topLeft, double width, double height) {
		super(name);
		if ( width <= 0 )
			throw new BadRectangleException("bad width");
		if ( height <= 0 )
			throw new BadRectangleException("bad height");
		this.topLeft = topLeft;
		this.width = width;
		this.height = height;
	}

	public Rectangle(Point topLeft, double width, double height) {
		this(nameGenerator.nextName(),topLeft,width,height);
	}

	public double getWidth() {
		return width;
	}
	
	public double getHeight() {
		return height;
	}
	
	public Point getTopLeft() {
		return topLeft;
	}
	
	public double perimeter() {
		return ( width + height ) * 2;
	}
	
	public double area() {
		return width * height;
	}
	
	public Rectangle translated(double dx, double dy) {
		return new Rectangle(topLeft.translated(dx, dy),width,height);
	}
	
	public Rectangle mirror(Point p) {
		Point br = new Point(topLeft.getX()+width,topLeft.getY()-height);
		return new Rectangle(br.mirror(p),width,height);
	}
	
	public Rectangle xMirror(double y) {
		Point bl = new Point(topLeft.getX(),topLeft.getY()-height);
		Point mbl = bl.xMirror(y);
		// return new Rectangle(new Point(topLeft.getX(),mbr.getY()), width, height);
		return new Rectangle(mbl, width, height);

	}
	
	public Rectangle yMirror(double x) {
		Point br = new Point(topLeft.getX()+width,topLeft.getY()-height);
		Point mbr = br.yMirror(x);
		return new Rectangle(new Point(mbr.getX(),topLeft.getY()),width, height);
	}
	
	public Type type() {
		return Type.RECTANGLE;
	}
	
	public String toString() {
		return super.toString() + "top left = " + topLeft + "\nwidth = " + getWidth() + ", height = " + getHeight();
	}
	
	public void draw(WhiteBoard wb) {
		super.draw(wb);
		Point br = new Point(topLeft.getX()+width,topLeft.getY()-height);
		topLeft.draw(wb,getColor());
		wb.drawLine(topLeft.getX(), topLeft.getY(), br.getX(), topLeft.getY());
		wb.drawLine(topLeft.getX(), br.getY(), br.getX(), br.getY());
		wb.drawLine(topLeft.getX(), topLeft.getY(), topLeft.getX(), br.getY());
		wb.drawLine(br.getX(), topLeft.getY(), br.getX(), br.getY());
		wb.drawString(getName(), (2*topLeft.getX()+width)/2, topLeft.getY());
	}
}



