package tiei.ajp.shape;

public class Triangle extends Shape {
	
	private Point vertex1;
	private Point vertex2;
	private Point vertex3;
	
	private static NameGenerator nameGenerator = new NameGenerator("T");
	
	public Triangle(String name, Point vertex1, Point vertex2, Point vertex3) {
		super(name);
		this.vertex1 = vertex1;
		this.vertex2 = vertex2;
		this.vertex3 = vertex3;
	}
	
	public Triangle(Point vertex1, Point vertex2, Point vertex3) {
		this(nameGenerator.nextName(),vertex1,vertex2,vertex3);
	}
	
	@Override
	public Type type() {
		return Type.TRIANGLE;
	}
	
	@Override
	public String toString() {
		return super.toString() + "vertex 1 = " + vertex1 + "\nvertex 2 = " + vertex2 + "\nvertext 3 = " + vertex3;
	}
	
	@Override
	public Shape translated(double dx, double dy) {
		return new Triangle(vertex1.translated(dx, dy),vertex2.translated(dx, dy),vertex3.translated(dx, dy));
	}
	
	@Override
	public Shape mirror(Point p) {
		return new Triangle(vertex1.mirror(p),vertex2.mirror(p),vertex3.mirror(p));
	}
	
	@Override
	public Shape xMirror(double y) {
		return new Triangle(vertex1.xMirror(y),vertex2.xMirror(y),vertex3.xMirror(y));
	}
	
	@Override
	public Shape yMirror(double x) {
		return new Triangle(vertex1.yMirror(x),vertex2.yMirror(x),vertex3.yMirror(x));
	}
	
	@Override
	public void draw(WhiteBoard wb) {
		super.draw(wb);
		vertex1.draw(wb,getColor());
		vertex2.draw(wb,getColor());
		wb.drawLine(vertex1.getX(), vertex1.getY(), vertex2.getX(), vertex2.getY());
		vertex3.draw(wb,getColor());
		wb.drawLine(vertex2.getX(), vertex2.getY(), vertex3.getX(), vertex3.getY());
		wb.drawLine(vertex3.getX(), vertex3.getY(), vertex1.getX(), vertex1.getY());
	}

}
