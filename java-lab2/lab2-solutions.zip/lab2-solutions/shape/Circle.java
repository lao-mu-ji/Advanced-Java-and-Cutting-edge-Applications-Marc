package tiei.ajp.shape;

public class Circle extends Shape {
	
	private Point center;
	private double radius;
	
	private static NameGenerator nameGenerator = new NameGenerator("C");
	
	public Circle(Point center, double radius) {
		this(nameGenerator.nextName(),center,radius);
	}
	
	public Circle(String name, Point center, double radius) {
		super(name);
		this.center = center;
		this.radius = radius;
	}
	
	public double perimeter() {
		return 2 * Math.PI * radius;
	}
	
	public double area() {
		return Math.PI * Math.pow(radius, 2);
	}
	
	@Override
	public String toString() {
		return super.toString() + "center = " + center + "\nradius = " + radius;
	}

	@Override
	public Type type() {
		return Type.CIRCLE;
	}

	@Override
	public Shape translated(double dx, double dy) {
		return new Circle(center.translated(dx, dy),radius);
	}

	@Override
	public Shape mirror(Point p) {
		return new Circle(center.mirror(p),radius);
	}

	@Override
	public Shape xMirror(double y) {
		return new Circle(center.xMirror(y),radius);
	}

	@Override
	public Shape yMirror(double x) {
		return new Circle(center.yMirror(x),radius);
	}
	
	@Override
	public void draw(WhiteBoard wb) {
		super.draw(wb);
		wb.drawString(getName(), center.getX(), center.getY()+radius);
		wb.drawCircle(center.getX(), center.getY(), radius);
	}
}
