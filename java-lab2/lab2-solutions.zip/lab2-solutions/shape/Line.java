//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.shape;

public class Line extends Shape {
	
	private Point start;
	private Point end;
	
	private static NameGenerator nameGenerator = new NameGenerator("L");
	
	public Line(String name, Point start, Point end) {
		super(name);
		this.start = start;
		this.end = end;
	}
	
	public Line(Point start, Point end) {
		this(nameGenerator.nextName(),start,end);
	}
		
	public Type type() {
		return Type.LINE;
	}
	
	public String toString() {
		return super.toString() + "start = " + start + "\nend = " + end;
	}
	
	public Line translated(double dx, double dy) {
		return new Line(start.translated(dx, dy),end.translated(dx, dy));
	}
	
	public Line mirror(Point p) {
		return new Line(start.mirror(p),end.mirror(p));
	}
	
	public Line xMirror(double y) {
		return new Line(start.xMirror(y),end.xMirror(y));
	}
	
	public Line yMirror(double x) {
		return new Line(start.yMirror(x),end.yMirror(x));
	}
	
	public void draw(WhiteBoard wb) {
		super.draw(wb);
		start.draw(wb,getColor());
		end.draw(wb,getColor());
		wb.drawLine(start.getX(), start.getY(), end.getX(), end.getY());
		wb.drawString(getName(), (start.getX()+end.getX())/2, (start.getY()+end.getY())/2);
	}
}
