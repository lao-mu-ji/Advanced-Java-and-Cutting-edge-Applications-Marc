//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.shape;

public class Point extends Shape {
	
	private double x;
	private double y;
	
	private static NameGenerator nameGenerator = new NameGenerator("P");
	
	public Point(double x, double y) {
		this(nameGenerator.nextName(),x,y);
	}
	
	public Point(String name, double x, double y) {
		super(name);
		this.x = x;
		this.y = y;
	}
	
	public Point() {
		super("O");
		this.x = 0;
		this.y = 0;
	}
	
	public Type type() {
		return Type.POINT;
	}
	
	public double getX() {
		return this.x;
	}
	
	public double getY() {
		return this.y;
	}
	
	public Point translated(double dx, double dy) {
		return new Point(x + dx, y + dy);
	}
	
	public Point mirror(Point p) {
		return new Point(2*p.x - x,2*p.y - y);
	}
	
	public Point xMirror(double y) {
		return new Point(x, 2*y - this.y);
	}
	
	public Point yMirror(double x) {
		return new Point(2*x - this.x,y);
	}

	public double distance(Point p) {
		return distance(x, y, p.x, p.y);
	}
	
	public double distance() {
		return distance(x,y,0,0);
	}
	
	public String toString() {
		return super.toString() + "x = " + x + ", y = " + y;
	}
	
	public void draw(WhiteBoard wb) {
		super.draw(wb);
		wb.drawPoint(x, y);
		wb.drawString(getName(), x, y);
	}
	
	private double distance(double x1, double y1, double x2, double y2) {
		return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
	}
}




