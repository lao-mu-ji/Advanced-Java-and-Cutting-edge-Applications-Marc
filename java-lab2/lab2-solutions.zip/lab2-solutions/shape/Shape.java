//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.shape;

import java.awt.Color;

public abstract class Shape {
	
	public enum Type { POINT, LINE, RECTANGLE, SQUARE, TRIANGLE, CIRCLE };

	private static final Color[] COLORS = { Color.BLUE, Color.GREEN, Color.RED, Color.YELLOW, Color.ORANGE, Color.CYAN, Color.PINK };
	private static int current = 0;
	
	private Color color;
	private String name;
	
	public Shape(String name) {
		this.color = COLORS[current++];
		if ( current == COLORS.length )
			current = 0;
		this.name = name;
	}
	
	public Color getColor() {
		return color;
	}
	
	public String getName() {
		return name;
	}
	
	public void draw(WhiteBoard wb) {
		wb.setColor(this.color);
	}
	
	public void draw(WhiteBoard wb, Color color) {
		wb.setColor(color);
	}	
	
	public String toString() {
		return name + "(" + type() + "): ";
	}
	
	public abstract Type type();
	
	public abstract Shape translated(double dx, double dy);
	
	public abstract Shape mirror(Point p);
	
	public abstract Shape xMirror(double y);
	
	public abstract Shape yMirror(double x);

}
