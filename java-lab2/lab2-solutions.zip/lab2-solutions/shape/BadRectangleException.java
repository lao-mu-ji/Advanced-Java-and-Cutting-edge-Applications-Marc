//
// Advanced Java Programming
// TIEI - Fall 2024
//
package tiei.ajp.shape;

public class BadRectangleException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public BadRectangleException(String msg) {
		super(msg);
	}

}
